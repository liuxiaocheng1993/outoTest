#coding:utf-8
'''
数据操作
'''