#coding:utf-8
'''
此包只放一些基本方法
比如操作Excel,json
'''